README.txt

CSCI E-3 Introduction to Web Programming Using Javascript
Harvard University Extension School 
HW#2a

This is a README file. It’s a common way for developers to provide basic information to each other about a program - how it works, technical user documentation, contact information for the author, copyright, etc. 

To see the instructions for this assignment, open the file CSCIE3ProjectUnit2A.html in your browser and follow the directions.

